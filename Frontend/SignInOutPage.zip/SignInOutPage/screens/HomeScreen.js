import React from 'react';
import { View, Text, Button, StyleSheet, StatusBar } from 'react-native';
import { useTheme } from '@react-navigation/native';
import {Container} from 'native-base';

import ActionButton from 'react-native-action-button';
import Icon from 'react-native-vector-icons/Ionicons';
const HomeScreen = ({navigation}) => {

  const { colors } = useTheme();

  const theme = useTheme();
  
    return (
      <Container>
      <View 
      style={styles.container}
      >
      
        
      {/*<Button
        title="Go to details screen"
        onPress={() => navigation.navigate("Widget")}
      />

      
      
        {/* Rest of the app comes ABOVE the action button component !*/}
        
        <ActionButton buttonColor="#00000f">
          <ActionButton.Item buttonColor='#9b59b6' title="Support" onPress={() => console.log("notes tapped!")}>
            <Icon name="md-help" style={styles.actionButtonIcon} />
          </ActionButton.Item>
          <ActionButton.Item buttonColor='#3498db' title="Notifications" onPress={() => {}}>
            <Icon name="md-notifications-off" style={styles.actionButtonIcon} />
          </ActionButton.Item>
          <ActionButton.Item buttonColor='#1abc9c' title="Search" onPress={() => {}}>
            <Icon name="md-search" style={styles.actionButtonIcon} />
          </ActionButton.Item>
          <ActionButton.Item buttonColor='rgba(231,76,60,1)' title="Report" onPress={() => {}}>
            <Icon name="md-warning" style={styles.actionButtonIcon} />
          </ActionButton.Item>
        </ActionButton>
      </View>
   
      </Container>
    );
};

export default HomeScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1, 
    alignItems: 'center', 
    justifyContent: 'center'
  },
});
