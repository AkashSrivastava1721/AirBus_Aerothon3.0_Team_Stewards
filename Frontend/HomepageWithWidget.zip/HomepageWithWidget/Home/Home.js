import * as React from 'react';
import { Avatar, Button, Card, Title, Paragraph } from 'react-native-paper';
import Search from '../SearchBar/Search'
const LeftContent = props => <Avatar.Icon {...props} icon="folder" />

const MyComponent = () => (
  <Card>
    <h1>About Air Crafts</h1>
    <div>
      <Search/>
    </div>
    <Card.Title title="Commercial Aircraft" subtitle="Card Subtitle" left={LeftContent} />
    <Card.Cover source={{ uri: 'https://airbus-h.assetsadobe2.com/is/image/content/dam/channel-specific/website-/products-and-services/aircraft/airbus-passenger-aircraft-family-formation2.png?wid=1920&fit=fit,1&qlt=85,0' }} />
    <Card.Content>
      <Title> Description</Title>
      <Paragraph>Commercial aircraft services. Airbus applies cutting-edge technology and advanced science to support its global customer base with a wide range of flexible service options.The company understands the    importance of providing customers with the best-possible solutions, and constantly strives to innovate and implement increasingly efficient methods.This quest for efficiency creates genuine value, limiting time that         aircraft spend on the ground and making sure they are flying at full capacity when in the air – creating real savings for customers.</Paragraph>
    </Card.Content>
    <Card.Title title="Helicopter" subtitle="Card Subtitle" left={LeftContent} />
    <Card.Cover source={{ uri: 'https://airbus-h.assetsadobe2.com/is/image/content/dam/products-and-solutions/commercial-helicopters/h145/H145-landingPage.jpg?wid=1920&fit=fit,1&qlt=85,0' }} />
    <Card.Content>
      <Title> Description</Title>
      <Paragraph>HCare service offer. The moment an Airbus helicopter is delivered, one of the company’s primary missions begins: providing the customer with the necessary support and services to carry out their operations efficiently, safely and cost-effectively. Airbus Helicopters’ global Customer Services network works around the clock to fulfill this mission, bringing tailor-made and competitive solutions to the customer’s doorstep.</Paragraph>
    </Card.Content>
    <Card.Title title="Defence" subtitle="Card Subtitle" left={LeftContent} />
    <Card.Cover source={{ uri: 'https://airbus-h.assetsadobe2.com/is/image/content/dam/products-and-solutions/military-aircraft/a400m/airbus-a400m-banner-defence.jpg?wid=1920&fit=fit,1&qlt=85,0' }} />
    <Card.Content>
      <Title> Description</Title>
      <Paragraph>Card Defence.In today’s increasingly complex threat environment, Airbus brings interoperable and collaborative solutions to ensure superiority for combat systems across the five operational domains: land, air, sea, space and cyber.Airbus combines more than 50 years of field-proven technology with next-generation systems-of-systems architecture in providing a more digitalised, more collaborative and agile operating environment.Airbus know-how is underscored by its prime contractor role for Europe’s Future Combat Air System (FCAS) – a network of manned and unmanned platforms from fighter and drones to satellites; its development of the Multi-Domain Combat Cloud (MDCC) – a decentralised, cyber-resilient, collaborative information network using cloud-based technologies; and implementation of the Network for the Sky (NFTS) – a resilient global-mesh military communications solution that allows aircraft to be fully part of a high-speed connected battlespace.The company’s world-class portfolio of products includes the Eurofighter Typhoon swing-role combat aircraft; the A400M, C295 and CN235 airlifters; the A330 Multi-Role Tanker Transport; along with robust, dependable unmanned aerial systems (UAS). For networks and systems, Airbus’ secure and resilient communications capabilities provide comprehensive bandwidth and best-in-class capabilities.t</Paragraph>
    </Card.Content>
    <Card.Title title="Space" subtitle="Card Subtitle" left={LeftContent} />
    <Card.Cover source={{ uri: 'https://airbus-h.assetsadobe2.com/is/image/content/dam/channel-specific/website-/products-and-services/space/space-exploration/web.space.spacexploration.juice.jpg?wid=1920&fit=fit,1&qlt=85,0' }} />
    <Card.Content>
      <Title> Description</Title>
      <Paragraph>Our vision: making space a universe of possibilities for everyone. At Airbus, our purpose is to improve life on Earth and beyond through our cutting-edge space technologies. With every technological breakthrough, we bring people closer together, we navigate new frontiers and we discover new and unexplored destinations. And we don't just take innovations to space – our space solutions and projects help solve global challenges on Earth.But we don’t stop there: we envisage a future where our human economy expands beyond Earth’s orbit and everyone benefits from the value of space. Explore, discover, connect: together, we can make tomorrow more than just another day.Whether mapping every star in our galaxy or looking back at planet Earth, Airbus has been helping to answer big questions from space and advance space exploration for more than 50 years. Supplying reliable systems that range from electronic components to full telecommunications relay platforms, scientific satellites and crewed spacecraft, developing the technology to send spaceships to planets – Airbus provides solutions for customers and their programmes around the globe.ArianeGroup, a joint venture with Safran, is the prime contractor for Europe’s record-breaking Ariane launcher. Applying the expertise of two leading contributors to modern launch vehicles, ArianeGroup develops innovative and competitive space solutions. Airbus Defence and Space has accumulated over 30 years of in-orbit operation, launching its first Earth observation satellite in 1986.</Paragraph>
    </Card.Content>
  </Card>
  
);

export default MyComponent;