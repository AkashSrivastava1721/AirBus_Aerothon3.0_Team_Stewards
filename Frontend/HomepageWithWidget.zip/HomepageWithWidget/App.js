import React, { Component } from 'react';
import { StyleSheet, View } from 'react-native';
import ActionButton from 'react-native-action-button';
import Icon from 'react-native-vector-icons/Ionicons';
import Chat from './chatbot/Chat'
import Search from './SearchBar/Search'
import Report from './ReportBox/Report'
import Notifications from './Notification/Announcement'
import Home from './Home/Home'

export default class App extends Component {


  state = {
    screen:0
  }

  onScreenChange= ()=>{
    if(this.state.screen==0)
      return (
          <Home/>
      )
    else if(this.state.screen == 1)
      return (
          <Chat/>);
    else if(this.state.screen == 2)
      return (
          <Notifications/>);
    else if(this.state.screen == 3)
      return (
          <Search/>);
    else if(this.state.screen == 4)
      return (
          <Report/>);
  }

  render() {
    return (
      <View style={{flex:1, backgroundColor: 'white'}}>
        {this.onScreenChange()}
        <View style={{flex:1, backgroundColor: '#f3f3f3'}}>
        <ActionButton buttonColor="#00000f">
          <ActionButton.Item buttonColor='#9b59b6' title="Support" onPress={() => {
            this.setState({screen:1})
          }}>
            <Icon name="md-help" style={styles.actionButtonIcon} />
          </ActionButton.Item>
          <ActionButton.Item buttonColor='#3498db' title="Notifications" onPress={() => {
            this.setState({screen:2})
          }}>
            <Icon name="md-notifications-off" style={styles.actionButtonIcon} />
          </ActionButton.Item>
          <ActionButton.Item buttonColor='#1abc9c' title="Search"  onPress={() => {
            this.setState({screen:3})
          }}>
            <Icon name="md-search" style={styles.actionButtonIcon} />
          </ActionButton.Item>
          <ActionButton.Item buttonColor='rgba(231,76,60,1)' title="Report"  onPress={() => {
            this.setState({screen:4})
          }}>
            <Icon name="md-warning" style={styles.actionButtonIcon} />
          </ActionButton.Item>
        </ActionButton>
      </View>
      </View>
    );
  }
}
 
const styles = StyleSheet.create({
  actionButtonIcon: {
    fontSize: 20,
    height: 22,
    color: 'white',
  },
});